#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

string format(int score, int level, int livesLeft, int healthLeft, int squirts, int gold, int sonar, int oil)
{
    string text = "Scr: ";
    text += (to_string(score) + " Lvl: " + to_string(level) +  " Lives: " + to_string(livesLeft) + " Hlth: " + to_string(healthLeft) + "% Wtr: " + to_string(squirts) + " Gld: " + to_string(gold) + " Sonar: " + to_string(sonar) + " Oil Left: " + to_string(oil));
    
    return text;
}

void StudentWorld::setDisplayText()
{
    int score = getScore();
    int level = getLevel();
    int livesLeft = getLives();
    int healthLeft = m_frackman->health();
    int squirts = m_frackman->numSquirts();
    int gold = m_frackman->numGold();
    int sonar = m_frackman->numSonar();
    int oil = 0;
    
    string s = format(score, level, livesLeft, healthLeft, squirts, gold, sonar, oil);
    
    setGameStatText(s);
}

int StudentWorld::init()
{
    m_frackman = new FrackMan(this);        // create FrackMan object and insert at right location
    
    // Draw left half of dirt
    for (int col = 0; col < 30; col++)
    {
        for (int row = 0; row < 60; row++)
        {
            m_dirt[col][row] = new Dirt(col, row, this);
        }
    }
    
    // Draw right half of dirt
    for (int col = 34; col < 64; col++)
    {
        for (int row = 0; row < 60; row++)
        {
            m_dirt[col][row] = new Dirt(col, row, this);
        }
    }
    
    // Bottom of mineshaft
    for (int col = 30; col < 34; col++)
    {
        for (int row = 0; row < 4; row++)
        {
            m_dirt[col][row] = new Dirt(col, row, this);
        }
    }
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    // Delete left half of dirt
    
    for (int col = 0; col < 30; col++)
    {
        for (int row = 0; row < 60; row++)
        {
            delete m_dirt[col][row];
        }
    }
    
    // Delete right half of dirt
    for (int col = 34; col < 64; col++)
    {
        for (int row = 0; row < 60; row++)
        {
            delete m_dirt[col][row];
        }
    }
    
    for (int col = 30; col < 34; col++)
    {
        for (int row = 0; row < 4; row++)
        {
            delete m_dirt[col][row];
        }
    }
    
    delete m_frackman;
    
    //        // Delete contents in vector
    //        for(int k = 0; k < frack_vector.size(); k++)
    //            delete frack_vector[k];
    //
    //        frack_vector.clear();
    
}

bool StudentWorld::isDirt(int x, int y)
{
    if (m_dirt[x][y] != nullptr)
        return true;
    else
        return false;
    
}

void StudentWorld::cleanDirtInTheWay(int x, int y)
{
    
    for (int i = x; i < x + 4; i++)
    {
        for (int j = y; j < y + 4; j++)
        {
            if (i >= 0 && i < 64 && j < 60 && j >=0)
            {
                if (isDirt(i, j))
                {
                    playSound(SOUND_DIG);
                    delete m_dirt[i][j];
                    m_dirt[i][j] = NULL;
                }
            }
        }
    }
    
}

//Destructor 
StudentWorld::~StudentWorld()
{
    // Delete left half of dirt
    
    for (int col = 0; col < 30; col++)
    {
        for (int row = 0; row < 60; row++)
        {
            delete m_dirt[col][row];
        }
    }
    
    // Delete right half of dirt
    for (int col = 34; col < 64; col++)
    {
        for (int row = 0; row < 60; row++)
        {
            delete m_dirt[col][row];
        }
    }
    
    for (int col = 30; col < 34; col++)
    {
        for (int row = 0; row < 4; row++)
        {
            delete m_dirt[col][row];
        }
    }
    
    delete m_frackman;
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp


/*
 
 // PSEUDOCODE PROVIDED IN THE SPEC //
 
int StudentWorld::move()
{
    //Update the Game Status Line
    updateDisplayText();            //update the score/lives/level text at screen top
    
    // The term "Actors" refers to all Protesters, the player, Goodies
    // Boulders, Barrels of oil, Holes, Squirts, the Exit, etc.
    
    //Give each Actor a chance to do something
    for each of the actors in the game world
    {
        if (actor[i] is still active/alive)
        {
            //ask each actor to do something (e.g. move)
            tellThisActorToDoSomething(actor[i]);
            
            if (theplayerDiedDuringThisTick() == true)
                return GWSTATUS_PLAYER_DIED;
            
            if (theplayerCompletedTheCurrentLevel() == true)
            {
                return GWSTATUS_FINISHED_LEVEL;
            }
        }
    }
    
    // Remove newly-dead actors after each tick
    removeDeadGameObjects();        // delete dead game objects
    
    //return the proper result
    if (theplayerDiedDuringThisTick() == true)
        return GWSTATUS_PLAYER_DIED;
    
    // If the player has collected all of the Barrels on the level, then
    // return the result that the player finished the level
    if (theplayerCompletedTheCurrentLevel() == true)
    {
        playFinishedLevelSound();
        return GWSTATUS_FINISHED_LEVEL;
    }
    
    // the player hasn't completed the current level and hasn't died
    // let them continue playing the current level
    return GWSTATUS_CONTINUE_GAME;
    
}

*/