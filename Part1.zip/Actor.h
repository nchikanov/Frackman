#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;

class Actor : public GraphObject
{
public:
    // Double check this to make sure...
    Actor(int imageID, int startX, int startY, Direction dir, double size, unsigned int depth, StudentWorld* sW)
    :GraphObject(imageID, startX, startY, dir, size, depth)
    {
        m_health = 100;
        setVisible(true);
        sWorld = sW;
    }
 
    virtual ~Actor() {setVisible(false);}       // Reevaluate this later, do we need something here?
    
    virtual void doSomething() {};
    
    int currentX() {return getX();}
    int currentY() {return getY();}
    
    void setHealth(int health) { m_health = health; }
    int health() { return m_health; }

    StudentWorld* getWorld() {return sWorld;}
    
private:
    int m_health;                               // If m_health of any reaches 0, not alive.
    StudentWorld* sWorld;

};

class Dirt : public Actor
{
public:
    Dirt(int x, int y, StudentWorld* sW) : Actor(IID_DIRT, x, y, right, .25, 3, sW) {};
    virtual ~Dirt() {};             // Double check if this needs to be virtual?
};

class FrackMan : public Actor
{
public:
    FrackMan(StudentWorld* sW) : Actor(IID_PLAYER, 30, 60, right, 1.0, 0, sW)
    {
        m_hitPts = 10;
        m_numSquirts = 5;
        m_numSonar = 1;
        m_numGoldNugs = 0;
    }
    virtual ~FrackMan(){};
    
    int numSquirts() {return m_numSquirts;}
    int hitPts() {return m_hitPts;}
    int numSonar() {return m_numSonar;}
    int numGold() {return m_numGoldNugs;}

    virtual void doSomething();
    
private:
    // Health: Loses 20% each time he's yelled at
    int m_numSquirts;
    int m_hitPts;
    int m_numSonar;
    int m_numGoldNugs;
    
};

class RegularProtester : public Actor
{
    
};

class HardcoreProtester : public RegularProtester
{
    
};

class Goodie : public Actor
{
    
};

class Water : public Goodie
{
    
};

class SonarKit : public Goodie
{
    
};

class GoldNugget : public Goodie
{
    
};

class Squirt : public Actor
{
    
};

class Boulder : public Actor
{
    
};

#endif // ACTOR_H_

