#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

void FrackMan::doSomething()
{
    if (health() == 0)
        return;
    
    /*
    if (userPressesEscapeKey)
        setHealth(0);
    
//  The code in your StudentWorld class should detect that the FrackMan has died and address this appropriately (e.g., replay the level from scratch, or end the game if the player has run out of lives).
    
    
    if (userPressesSpaceBar)
    {
        if (m_numSquirts != 0)
        {
            // To fireSquirt(), player must create and add new Squirt object into oil field at a location that is 4 squares immediately in front of FrackMan, facing the same dir as FrackMan.
            // Must play sound SOUND_PLAYER_SQUIRT
            // Check for more details on this in the spec...Don't have to worry about Squirt for rn.
            fireSquirt();
            m_numSquirts--;
        }
    }
    */
    
    //    iv. It must have a limited version of a doSomething() method that lets
    //    the user pick a direction by hitting a directional key. If the player hits a directional key during the current tick, it updates the FrackMan’s location to the target square, removing any Dirt objects that overlap with the FrackMan’s 4x4 graphic image. To move the FrackMan, all this doSomething() method has to do is properly adjust the player’s X,Y coordinates using GraphObject’s moveTo() method and our graphics system will automatically animate its movement it around the oil field!
    
    
    int value;
    if (getWorld()->getKey(value) == true)
    {
        switch(value)
        {
            case KEY_PRESS_LEFT:
                if (currentX() > 0)
                    moveTo(currentX() - 1, currentY());
                else
                    moveTo(currentX(), currentY());
                setDirection(left);
                // remove dirt
                
                getWorld()->cleanDirtInTheWay(currentX(), currentY());
                    
                break;
            case KEY_PRESS_RIGHT:
                if (currentX() < 60)
                    moveTo(currentX() + 1, currentY());
                else
                    moveTo(currentX(), currentY());
                
                setDirection(right);
                
                // remove dirt
                getWorld()->cleanDirtInTheWay(currentX(), currentY());
                
                break;
            case KEY_PRESS_DOWN:
                if (currentY() > 0)
                    moveTo(currentX(), currentY() - 1);
                else
                    moveTo(currentX(), currentY());
                
                setDirection(down);
                
                // remove dirt
                getWorld()->cleanDirtInTheWay(currentX(), currentY());
               
                break;
            case KEY_PRESS_UP:
                if (currentY() < 60)
                    moveTo(currentX(), currentY() + 1);
                else
                    moveTo(currentX(), currentY());
                
                setDirection(up);
                
                // remove dirt
                getWorld()->cleanDirtInTheWay(currentX(), currentY());
                
                break;
            case KEY_PRESS_SPACE:
                // Squirt, look above.
                break;
            case KEY_PRESS_ESCAPE:
                setHealth(0);
                break;
        }
        
    }
    
    
}

