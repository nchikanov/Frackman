#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <vector>
#include <string>
using namespace std;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
    // Constructor
	StudentWorld(std::string assetDir)
	 : GameWorld(assetDir)
	{
	}
    
    // Create Game Stat Text
    void setDisplayText();

    // Required to Initialize
    virtual int init();
    virtual void cleanUp();
    virtual int move()
    {
        m_frackman->doSomething();
        
        setDisplayText();
        
        //decLives();
        return GWSTATUS_CONTINUE_GAME;
        //return GWSTATUS_PLAYER_DIED;
    }

    
    // Helper Functions for Dirt
    bool isDirt(int x, int y);
    void cleanDirtInTheWay(int x, int y);
    
    // Destructor
    ~StudentWorld();


private:
    Dirt* m_dirt[64][60];           // Array of pointer to Dirt
    FrackMan* m_frackman;
};

#endif // STUDENTWORLD_H_

/*
Create a limited version of the StudentWorld class.
i. Add any private member variables to this class required to keep
track of all Dirt in the oil field as well as the FrackMan object. You may ignore all other items in the oil field such as Boulders, Barrels of oil, Protesters, Nuggets, etc. for part #1.
ii. Implement a constructor for this class that initializes all member variables required for proper gameplay.
iii. Implement a destructor for this class that frees any remaining dynamically allocated data that has not yet been freed at the time the class is destroyed (e.g., the FrackMan and all remaining Dirt).
iv. Implement the init() method in this class. It must:
1. Create the FrackMan object and insert it into the oil field at
the right starting location (see the StudentWorld init() section of this document for details on the starting location).
2. Creates all of the oil field’s Dirt objects and inserts them into a data structure that tracks active Dirt (see the StudentWorld init() section for details on where to place Dirt, and what data structure to use track all of the remaining Dirt in the game).
 
v. Implement the move() method in your StudentWorld class. During each tick, it must ask your FrackMan object to do something. Your move() method need not check to see if the FrackMan has died or not; you may assume at this point that the FrackMan cannot die. Nor need your move() method deal with any Protesters or other actors (e.g., Nuggets or Boulders) at this point – just the FrackMan.
 
vi. Implement a cleanup() method that frees any dynamically allocated data that was allocated during calls to the init() method or the move() method (e.g., it should delete all your allocated Dirt and the FrackMan). Note: Your StudentWorld class must have both a destructor and the cleanUp() method even though they likely do the same thing.
 
 */

